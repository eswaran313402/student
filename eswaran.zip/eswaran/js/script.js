// Example script for Student Database Website

document.addEventListener('DOMContentLoaded', function() {
    // Add Student Form Submission
    const addForm = document.getElementById('add-student-form');
    if (addForm) {
        addForm.addEventListener('submit', function(e) {
            e.preventDefault();
            alert('Student added! (Demo)');
        });
    }

    // Admin Login Form Submission
    const loginForm = document.getElementById('admin-login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            alert('Admin login successful! (Demo)');
        });
    }
});